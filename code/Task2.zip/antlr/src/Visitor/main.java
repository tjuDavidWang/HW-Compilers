package Visitor;

import org.antlr.runtime.tree.ParseTree;
import org.antlr.v4.runtime.CharStreams;
import org.antlr.v4.runtime.CommonTokenStream;
import pl0.pl0Lexer;
import pl0.pl0Parser;

public class main {
    public static void main(String[] args) {
        try {
            pl0Lexer lexer = new pl0Lexer(CharStreams.fromString("PROGRAM add VAR x,y; BEGIN x:=1; y:=2; z:=3; WHILE x<5 DO x:=x+1;y:=y*(x+y)-x; IF y>0 THEN y:=y-1; y:=y+x END"));
            CommonTokenStream tokens = new CommonTokenStream(lexer);
            pl0Parser parser = new pl0Parser(tokens);

            try {
                pl0Parser.ProgramContext tree = parser.program();
                pl0VisitorImpl visitor = new pl0VisitorImpl("mediaCode.txt", "symbol.txt");
                visitor.visit(tree);
                visitor.printCode();
                visitor.closeWriters();
            } catch (Exception e) {
                System.err.println("Error parsing program: " + e.getMessage());
            }
        } catch (Exception e) {
            System.err.println("Error creating lexer: " + e.getMessage());
        }
    }
}
