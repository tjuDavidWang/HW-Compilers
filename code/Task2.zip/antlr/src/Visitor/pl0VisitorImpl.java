package Visitor;

import org.antlr.v4.runtime.tree.TerminalNode;
import pl0.pl0BaseVisitor;
import pl0.pl0Parser;

import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;

public class pl0VisitorImpl extends pl0BaseVisitor<String> {
    private int tmpVarCount = 0;   // 中间变量的计数
    private int codeCount = 1; // 代码行数
    private int labelCount = 0; // 回填标签计数

    private List<String> codeLines = new ArrayList<>();  // 待输出的所有代码
    private List<Integer> labelValues = new ArrayList<>();   // 各个回填地址

    private List<String> varRecord = new ArrayList<>(); // 用于存储变量记录，错误处理用
    private List<String> constRecord = new ArrayList<>();   // 用于处理常量记录，错误处理用

    private PrintWriter mediateCodeGenerator; // 用于写入中间代码
    private PrintWriter symbolTableGenerator; // 打印符号表


    public pl0VisitorImpl(String codeFilename, String symbolTableFilename) {
        try {
            mediateCodeGenerator = new PrintWriter(new FileWriter(codeFilename, false)); // 覆盖模式
            symbolTableGenerator = new PrintWriter(new FileWriter(symbolTableFilename, false)); // 覆盖模式
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    // 用于写入符号表
    private void emitSymbol(String symbol) {
        symbolTableGenerator.println(symbol);
    }

    // 新的临时变量，用t做前缀
    private String newTemp() {
        return "t" + tmpVarCount++;
    }

    // 生成新的行数标签，用于后续回填
    private int newLineLabel() {
        labelValues.add(null);  // 初始时标签的值为空，后续要填入回填位
        return labelCount++;
    }

    private void emitCode(String code) {
        codeLines.add(code);
        this.codeCount++;
    }

    // 回填地址填入，并输出代码
    public void printCode() {
        for (int i = 0; i < codeLines.size(); i++) {
            String line = codeLines.get(i);
            // 替换所有的标签引用
            for (int j = 0; j < labelValues.size(); j++) {
                if (labelValues.get(j) != null) {
                    line = line.replace("$" + (j), labelValues.get(j).toString());
                }
            }
            mediateCodeGenerator.println(i + ": " + line);
        }
    }

    // 关闭文件写入
    public void closeWriters() {
        if (mediateCodeGenerator != null) {
            mediateCodeGenerator.close();
        }
        if (symbolTableGenerator != null) {
            symbolTableGenerator.close();
        }
    }

    // 常量声明
    @Override
    public String visitConstDeclaration(pl0Parser.ConstDeclarationContext ctx) {
        if (ctx.constDefinition() == null || ctx.constDefinition().isEmpty()) {
            System.err.println("Const Declaration Syntax Error");
            return null;
        }

        // 遍历所有的常量定义
        for (pl0Parser.ConstDefinitionContext constDef : ctx.constDefinition()) {
            // 确保定义不为空
            if (constDef == null) {
                System.err.println("Const Declaration Syntax Error");
                continue;
            }
            visit(constDef); // 进入每个常量定义
        }
        return null;
    }
    @Override
    public String visitConstDefinition(pl0Parser.ConstDefinitionContext ctx) {
        if (ctx.ID() == null || ctx.ID().getText() == null || ctx.INT() == null || ctx.INT().getText() == null) {
            System.err.println("Const definition Syntax Error");
            return null;
        }
        String constName = ctx.ID().getText();
        String constValue = ctx.INT().getText();
        constRecord.add(constName);
        emitSymbol(constName +" "+ constValue + " const");
        return null;
    }

    @Override
    public String visitVarDeclaration(pl0Parser.VarDeclarationContext ctx) {
        if (ctx.ID() == null || ctx.ID().isEmpty()) {
            System.err.println("Var declaration Syntax Error");
            return null;
        }
        for (TerminalNode idNode : ctx.ID()) {
            if (idNode == null || idNode.getText() == null) {
                System.err.println("Var declaration Syntax Error");
                continue; // 跳过无效的标识符，继续处理其他标识符
            }
            String varName = idNode.getText();
            varRecord.add(varName);
            emitSymbol(varName + " var");
        }
        return null;
    }

    @Override
    public String visitCompoundStatement(pl0Parser.CompoundStatementContext ctx) {
        if (ctx.statement() == null || ctx.statement().isEmpty()) {
            System.err.println("Compound Statement Syntax Error");
            return null;
        }
        // 遍历复合语句块中的所有语句
        for (pl0Parser.StatementContext stmtCtx : ctx.statement()) {
            if (stmtCtx == null) {
                System.err.println("Compound Statement Syntax Error");
                continue;
            }
            visit(stmtCtx); // 访问并处理每个子语句
        }
        return null;
    }
    @Override
    public String visitAssignmentStatement(pl0Parser.AssignmentStatementContext ctx) {
        // Handle assignment statement

        if (ctx.ID() == null || ctx.expression().getChild(0) == null) {
            System.err.println("Assignment Statement Syntax error");
            return null;
        }

        String varOrConstName = ctx.ID().toString(); // 获取变量

        // 重点，调用未声明的变量
        if (!varRecord.contains(varOrConstName) && !constRecord.contains(varOrConstName)) {
            System.err.println("Variable '" + varOrConstName + "' not declared");
            return null;
        }
        if(constRecord.contains(varOrConstName))
        {
            System.err.println("Const Variable '" + varOrConstName + "' can not be assigned");
            return null;
        }

        String var = ctx.ID().toString();
        String exprCode = visit(ctx.expression());
        emitCode(var + " = " + exprCode);
        return null;
    }

    @Override
    public String visitExpression(pl0Parser.ExpressionContext ctx) {
        if (ctx.getChildCount() == 0)
        {
            System.err.println("Expression syntax error");
            return null;
        }
        else if (ctx.getChildCount() == 1) {
            return visit(ctx.getChild(0)); // 直接返回单个子项的代码
        }
        else {
            // 可以进一步错误处理
            String left = visit(ctx.getChild(0));
            String op = ctx.getChild(1).getText();
            if(op == null)
            {
                System.err.println("Expression syntax Error");
                return null;
            }
            String right = visit(ctx.getChild(2));
            String temp = newTemp();
            emitCode(temp + " = " + left + " " + op + " " + right);
            return temp;
        }
    }

    @Override
    public String visitTerm(pl0Parser.TermContext ctx)
    {
        if (ctx.getChildCount() == 0)
        {
            System.err.println("Term syntax missing child");
            return null;
        }
        if (ctx.getChildCount() == 1) {
            // 仅有一个因子，直接访问它
            return visit(ctx.factor());
        } else {
            // 有多个因子，进行递归处理
            if(ctx.term() == null || ctx.factor() == null || ctx.mulOp() == null) {
                System.err.println("Expression syntax Error");
                return null;
            }
            String left = visit(ctx.term()); // 访问左侧项
            String right = visit(ctx.factor()); // 访问右侧因子
            String op = ctx.mulOp().getText();
            if(op == null)
            {
                System.err.println("Expression syntax Error");
                return null;
            }
            String temp = newTemp();
            emitCode(temp + " = " + left + " " + op + " " + right);
            return temp;
        }
    }

    @Override
    public String visitFactor(pl0Parser.FactorContext ctx)
    {
        if (ctx.ID() != null) {
            // 标识符
            return ctx.ID().getText();
        } else if (ctx.INT() != null) {
            // 整数
            return ctx.INT().getText();
        } else if (ctx.LPAREN() != null) {
            // 括号内的表达式
            return visit(ctx.expression());
        }
        else {
            System.err.println("Factor Syntax Error");
        }
        return null;
    }


    @Override
    public String visitConditionalStatement(pl0Parser.ConditionalStatementContext ctx) {

        if (ctx.condition().getChild(0) == null || ctx.statement().getChild(0) == null) {
            System.err.println("Conditional Statement syntax Error");
            return null;
        }

        int labelRight = newLineLabel(); // 用于条件成立时的跳转
        int labelWrong = newLineLabel(); // 用于条件不成立时的跳转

        String conditionCode = visit(ctx.condition());
        emitCode("if " + conditionCode + " goto $" + labelRight);

        // 生成中间代码
        emitCode("goto $" + labelWrong);
        labelValues.set(labelRight, codeCount -1);  // else部分，emit Code之后会多一个，本身有++，所以要减1才能表示下一个
        // 访问循环体
        visit(ctx.statement());
        // 产生中间代码之后，代码行数增长，填入数据便于后续回填
        labelValues.set(labelWrong, codeCount -1);
        return null;
    }


    @Override
    public String visitLoopStatement(pl0Parser.LoopStatementContext ctx)
    {

        if (ctx.condition().getChild(0) == null || ctx.statement().getChild(0) == null) {
            System.err.println("Conditional Statement syntax Error");
            return null;
        }

        int labelStart = newLineLabel();
        int labelStop = newLineLabel();
        int labelStmt = newLineLabel();

        labelValues.set(labelStart, codeCount -1); //在while最开始的时候进行赋值

        String conditionCode = visit(ctx.condition());
        emitCode("if " + conditionCode + " goto $" + labelStmt);

        emitCode("goto $" + labelStop);
        labelValues.set(labelStmt, codeCount -1);
        // 访问循环体
        visit(ctx.statement());
        // 产生中间代码
        emitCode("goto $" + labelStart);
        // 产生中间代码之后，代码行数增长，填入数据便于后续回填
        labelValues.set(labelStop, codeCount -1);
        return null;

    }

    @Override
    public String visitCondition(pl0Parser.ConditionContext ctx) {

        if (ctx.expression(0).getChild(0) == null || ctx.expression(1).getChild(0) == null) {
            System.err.println("Conditionsyntax Error");
            return null;
        }
        String leftExpr = visit(ctx.expression(0)); // 访问左侧表达式
        String rightExpr = visit(ctx.expression(1)); // 访问右侧表达式
        if(ctx.relOp() == null)
        {
            System.err.println("Conditionsyntax Error");
            return null;
        }
        String op = ctx.relOp().getText();
        return leftExpr + " " + op + " " + rightExpr;
    }
}

